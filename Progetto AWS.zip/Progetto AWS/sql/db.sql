-- Dump della struttura di tabella progettoaws.utente
CREATE TABLE IF NOT EXISTS `utente` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dump dei dati della tabella progettoaws.utente: ~2 rows (circa)
INSERT INTO `utente` (`ID`, `username`, `password`) VALUES
	(1, 'RiccardoAndronaco', 'teoria'),
	(2, 'RubenScopacasa', 'laboratorio');
